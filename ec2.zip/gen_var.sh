#!/bin/sh

echo $0
echo $1 #module
echo $2 #project

module = $1
project_name = $2

mkdir -p ./$project_name
wget -O ./$project_name/$module.zip https://raw.githubusercontent.com/OnagiNagao/terraform_template/master/$module.zip

echo "Enter instance name [default = aws-terraform-poc]: "
read instance_name

echo "Enter instance type [default = t2.micro]: "
read instance_type

echo ""
echo "Create file configuration ..."
echo "" > $instance_name.tfvars
if [ ${#instance_name} -ne 0 ]; then
    echo "instance_name = \"$instance_name\"" >> $instance_name.tfvars
fi

if [ ${#instance_type} -ne 0 ]; then
    echo "instance_type = \"$instance_type\"" >> $instance_name.tfvars
fi

if [ $? -eq 0 ]; then
    echo "******* CREATE FILE SUCCESSFUL *******"
    cat $instance_name.tfvars
    echo ""
    echo ""
    echo "Please run the follow commands to plan & apply terraform."
    echo "terraform plan -var-file=$instance_name.tfvars"
    echo "terraform apply -var-file=$instance_name.tfvars"
else
    echo "ERROR: Something wrong."
fi
