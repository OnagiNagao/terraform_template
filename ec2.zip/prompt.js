module.exports = [
    {
        type : "input",
        name : "aws_profile",
        default : "itm-ph-alpha",
        message : "The AWS profile:"
    },
    {
        type : "input",
        name : "aws_account_id",
        message : "The AWS account id:"
    },
    {
        type : "input",
        name : "aws_region",
        message : "The AWS region to create things:",
        default : "ap-southeast-1",
    },
    {
        type : "input",
        name : "vpc_id",
        message : "VPC ID for instances:"
    },
    {
        type : "input",
        name : "instance_name",
        message : "instance name for EC2:",
        default : "aws-terraform-poc"
    },
    {
        type : "input",
        name : "ami_id",
        message : "AMI ID for EC2:",
        default : "ami-5aab6739"
    },
    {
        type : "input",
        name : "instance_type",
        message : "Instances type for EC2:",
        default : "t2.micro"
    },
    {
        type : "input",
        name : "subnet_a_id",
        message : "Subnet id in ZoneA:"
    },
    {
        type : "input",
        name : "subnet_b_id",
        message : "Subnet id in ZoneB:"
    }
];