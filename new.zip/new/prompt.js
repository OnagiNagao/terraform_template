module.exports = [
    {
        type : "input",
        name : "aws_profile",
        default : "itm-ph-alpha",
        message : "The AWS profile:"
    },
    {
        type : "input",
        name : "aws_account_id",
        message : "The AWS account id:"
    },
    {
        type : "input",
        name : "aws_region",
        message : "The AWS region to create things:",
        default : "ap-southeast-1",
    }
];